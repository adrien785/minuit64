import { articles } from './journal-articles.mjs';

const journalPath = '/journal/';
const journalTitle = 'Le Journal Minuit 64';
const journalDescription = 'Des guides illustrés pour choisir vos voitures miniatures, comprendre l’échelle 1:64, monter un diorama et photographier votre collection.';
const publicationDate = '2026-11-10';
const paths = [journalPath, ...articles.map(articlePath)];

function articlePath(article) {
  return journalPath + article.slug + '/';
}

export function journal({ layout, head, crumbs, structured, escape, origin, productPath, cars, garages }) {
  function tags(article) {
    const wordCount = [article.lead, ...article.sections.map(section => section.body.replace(/<[^>]+>/g, ' '))]
      .join(' ').trim().split(/\s+/).length;
    return `<p class="journal-tag"><span>${escape(article.category)}</span><span>${Math.ceil(wordCount / 170)} min de lecture</span></p>`;
  }

  function articleCard(article, { featured = false, heading = 'h2' } = {}) {
    const card = featured ? 'journal-feature' : 'journal-card';
    const media = featured ? 'journal-feature-media' : 'journal-card-media';
    const copy = featured ? 'journal-feature-copy' : 'journal-card-copy';
    return `<a class="${card}" href="${articlePath(article)}">
    <div class="${media}"><img src="/${article.image}" alt="" width="1200" height="800" decoding="async" loading="lazy"></div>
    <div class="${copy}">${tags(article)}<${heading}>${escape(article.title)}</${heading}>
    <p>${escape(article.description)}</p><span class="journal-read" aria-hidden="true">Lire l’article ↗</span></div></a>`;
  }

  function cards(heading) {
    const [featured, ...others] = articles;
    return articleCard(featured, { featured: true, heading }) +
      `<div class="journal-card-grid">${others.map(article => articleCard(article, { heading })).join('')}</div>`;
  }

  const family = { label: 'Journal', path: journalPath };
  const breadcrumb = (article) => `<nav class="breadcrumbs" aria-label="Fil d’Ariane"><a href="/">Accueil</a>
    <span aria-hidden="true">/</span>${article
      ? `<a href="${journalPath}">Journal</a><span aria-hidden="true">/</span><span aria-current="page">${escape(article.shortTitle)}</span>`
      : '<span aria-current="page">Journal</span>'}</nav>`;

  function articlePage(article) {
    const related = articles.filter(other => other !== article);
    const path = articlePath(article);
    const product = [...cars, ...garages].find(item => item.id === article.product);
    const schema = {
      '@context': 'https://schema.org',
      '@type': 'BlogPosting',
      mainEntityOfPage: origin + path,
      headline: article.title,
      description: article.description,
      image: [origin + '/' + article.image],
      datePublished: publicationDate,
      inLanguage: 'fr-FR',
      author: { '@type': 'Organization', name: 'Minuit 64', url: origin + journalPath },
      publisher: { '@type': 'Organization', name: 'Minuit 64', url: origin + '/' },
    };
    const meta = head(article.title + ' | Minuit 64', article.description, path, article.image, 'article') +
      '\n  ' + crumbs(family, article.shortTitle, path) + '\n  ' + structured(schema);
    const links = related.map(other => `<li><a href="${articlePath(other)}">${escape(other.shortTitle)} <span aria-hidden="true">↗</span></a></li>`).join('');
    return layout(meta, `${breadcrumb(article)}
    <article class="journal-article">
      <header class="journal-hero">
        <div>${tags(article)}<h1>${escape(article.title)}</h1>
        <p class="journal-hero-lead">${escape(article.lead)}</p>
        <p class="journal-byline">Par Minuit 64 · <time datetime="${publicationDate}">10 novembre 2026</time></p></div>
        <figure class="journal-figure"><img src="/${article.image}" alt="${escape(article.alt)}" width="1200" height="800" fetchpriority="high"><figcaption>${escape(article.caption)}</figcaption></figure>
      </header>
      <div class="journal-columns">
        <nav class="journal-toc" aria-label="Dans cet article"><b>Dans cet article</b><ol>
          ${article.sections.map(section => `<li><a href="#${section.id}">${escape(section.title)}</a></li>`).join('')}
        </ol></nav>
        <div class="journal-prose">
          ${article.sections.map(section => `<section id="${section.id}"><h2>${escape(section.title)}</h2>${section.body}</section>`).join('')}
          ${article.sources?.length ? `<aside class="journal-sources"><h2>Sources et fiches de référence</h2><ul>${article.sources.map(([label, url]) => `<li><a href="${escape(url)}">${escape(label)}</a></li>`).join('')}</ul></aside>` : ''}
          ${product ? `<p class="journal-product-link">Dans la collection · <a href="${productPath(product)}">${escape(product.name)} ↗</a></p>` : ''}
        </div>
      </div>
      <aside class="journal-related"><h2>À lire aussi</h2><ul>${links}</ul></aside>
    </article>`, { journal: true, calculator: article.calculator });
  }

  return {
    paths,
    home: `<section class="journal-preview wrap" aria-labelledby="journal-title">
    <div class="section-head"><div><p class="eyebrow section-kicker"><span class="slashes">//</span> 04 / GUIDES DE COLLECTION</p>
    <h2 id="journal-title">LE JOURNAL<span>.</span></h2></div>
    <p>Comprendre les échelles, choisir ses miniatures et monter son premier décor de garage.</p></div>
    ${cards('h3')}<a class="button line journal-more" href="${journalPath}">Tous les articles ↗</a></section>`,
    pages: [
      [journalPath, layout(head(journalTitle + ' | Guides voitures miniatures 1:64', journalDescription, journalPath, articles[0].image) +
        '\n  ' + crumbs(family), `${breadcrumb()}<div class="journal-index"><div class="seo-heading">
        <p class="eyebrow section-kicker"><span class="slashes">//</span> GUIDES DE COLLECTION</p>
        <h1 class="journal-headline">Le Journal Minuit 64<span>.</span></h1><p>${escape(journalDescription)}</p>
        </div>${cards('h2')}</div>`, { journal: true })],
      ...articles.map(article => [articlePath(article), articlePage(article)]),
    ],
  };
}
