const figure = (image, alt, caption) => `<figure class="journal-figure"><img src="/assets/${image}" alt="${alt}" width="1200" height="800" loading="lazy" decoding="async"><figcaption>${caption}</figcaption></figure>`;
const checklist = (title, points) => `<div class="journal-callout"><h3>${title}</h3><ul>${points.map(point => `<li>${point}</li>`).join('')}</ul></div>`;

export const articles = [
  {
    slug: 'echelle-1-64-taille-voiture-miniature',
    category: 'Échelles',
    title: 'Échelle 1:64, quelle taille fait une voiture miniature ?',
    shortTitle: 'Comprendre l’échelle 1:64',
    description: 'Calculez la taille d’une voiture miniature au 1:64 et comparez-la aux échelles 1:43, 1:24 et 1:18.',
    lead: 'Une voiture de 4,50 m mesure environ 7 cm au 1:64. Voici comment retrouver cette taille et vérifier qu’un modèle rentre dans votre vitrine.',
    image: 'assets/01.jpg',
    alt: 'Nissan Skyline ER34 blanche en miniature, vue de trois quarts',
    caption: 'Skyline ER34 au 1:64 · Vue illustrative de la miniature.',
    product: '01',
    calculator: true,
    sources: [
      ['Mini GT · Catalogue des voitures au 1:64', 'https://minigt.tsm-models.com/'],
      ['Solido · Exemples de voitures au 1:43 et au 1:18', 'https://pro.solido.com/en/brand/1-solido'],
      ['Tamiya · Mazda MX-5 RF au 1:24', 'https://www.tamiya.com/english/products/24353/index.html'],
    ],
    sections: [
      { id: 'calcul', title: 'Divisez la dimension réelle par 64', body: `
      <p>Au 1:64, un millimètre sur la miniature représente 64 millimètres sur la voiture. Prenons une voiture hypothétique de 4,50 m. Convertissez sa longueur en millimètres, puis divisez-la par 64. Avec 4 500 ÷ 64, on obtient environ 70,3 mm, soit 7,03 cm. La même opération fonctionne pour la largeur. Pour ce coupé fictif, 1,85 m donnent 28,9 mm au 1:64. Vous pouvez aussi l’appliquer à l’empattement, la distance entre les essieux.</p>
      <div class="journal-calculator">
        <h3>Calculez la longueur au 1:64</h3>
        <label for="longueur-reelle">Longueur de la voiture réelle en mètres</label>
        <input id="longueur-reelle" type="text" inputmode="decimal" value="4,50" maxlength="8" autocomplete="off">
        <output id="longueur-miniature" for="longueur-reelle" aria-live="polite">70,3 mm</output>
        <p>Le résultat indique une longueur théorique, arrondie au dixième de millimètre.</p>
      </div>` },
      { id: 'comparaison', title: 'Comparez le 1:64 au 1:43, 1:24 et 1:18', body: `
      <p>Pour une même voiture, plus le nombre après les deux-points est petit, plus la miniature est grande. Le 1:64 laisse de la place pour réunir plusieurs modèles dans un décor. Une réplique au 1:43 occupera environ une fois et demie sa longueur. Au 1:24 ou au 1:18, mesurez d’abord la profondeur de l’étagère, surtout si vous exposez les voitures de biais.</p>
      <table class="journal-table">
        <caption>La même voiture hypothétique de 4,50 m</caption>
        <thead><tr><th scope="col">Échelle</th><th scope="col">Longueur théorique</th></tr></thead>
        <tbody><tr><th scope="row">1:64</th><td>70,3 mm<span class="journal-length" style="--length:28.1%" aria-hidden="true"></span></td></tr>
        <tr><th scope="row">1:43</th><td>104,7 mm<span class="journal-length" style="--length:41.9%" aria-hidden="true"></span></td></tr>
        <tr><th scope="row">1:24</th><td>187,5 mm<span class="journal-length" style="--length:75%" aria-hidden="true"></span></td></tr>
        <tr><th scope="row">1:18</th><td>250 mm<span class="journal-length" style="--length:100%" aria-hidden="true"></span></td></tr></tbody>
      </table>` },
      { id: 'vitrine', title: 'Mesurez la miniature et la place disponible', body: `
      <p>Le calcul part d’une version précise de l’auto. Un pare-chocs plus long, un aileron saillant ou une différence de fabrication peut changer la cote à retenir. Pour comparer deux versions, partez des mêmes points de mesure, d’un bout de la carrosserie à l’autre. Relevez séparément la largeur avec les rétroviseurs et la longueur du socle si vous comptez garder le modèle dessus.</p>
      <p>Pour choisir une vitrine, prenez les dimensions intérieures entre les parois et vérifiez l’ouverture de la porte. Une voiture placée en diagonale laisse souvent mieux voir le profil, mais elle peut demander davantage de profondeur. Découpez un rectangle en papier aux cotes du modèle et placez-le dans l’espace prévu pour vous en rendre compte.</p>
      <p>Pour passer de la vitrine à une scène complète, voyez <a href="/journal/creer-diorama-garage-1-64/">comment aménager un garage au 1:64</a>.</p>` },
    ],
  },
  {
    slug: 'choisir-premiere-voiture-miniature-1-64',
    category: 'Collection',
    title: 'Bien choisir sa première voiture miniature au 1:64',
    shortTitle: 'Choisir sa première miniature',
    description: 'Les détails à examiner avant de choisir une miniature au 1:64, de la carrosserie aux jantes en passant par la livrée.',
    lead: 'Une silhouette juste se repère de loin. La finesse des pièces et la qualité de l’assemblage se voient en changeant d’angle.',
    image: 'assets/03.jpg',
    alt: 'Nissan Skyline GT-R R34 bleue en miniature sur un fond sombre',
    caption: 'Skyline GT-R R34 V-Spec II · Vue illustrative de la finition bleue.',
    product: '03',
    sources: [
      ['Mini GT · Fiche de la Skyline ER34 Athlete/Collet', 'https://minigt.tsm-models.com/index.php?action=product-detail&b_id=18&id=1838'],
      ['OttOmobile · Exemples de miniatures en résine', 'https://otto-models.com/fr/la-collection-ottomobile'],
    ],
    sections: [
      { id: 'version', title: 'Choisissez d’abord la version qui vous plaît', body: `
      <p>Un même nom peut désigner plusieurs générations, couleurs ou préparations. Une Skyline GT-R R34 de route et une Skyline ER34 transformée par Liberty Walk ont un air de famille. Elles se distinguent pourtant par la largeur des ailes, le dessin des boucliers et la position de l’aileron. Notez la version complète et la référence fabricant pour comparer les bonnes fiches. Choisissez ensuite le modèle que vous avez envie d’exposer, selon un thème qui vous parle. Une couleur, une époque ou les voitures de rallye suffisent à commencer une collection.</p>` },
      { id: 'finitions', title: 'Inspectez la peinture, les vitrages et les roues', body: `
      <p>Le terme <em>die-cast</em> désigne ici une carrosserie en alliage moulé. Des vitrages transparents et de petites pièces en plastique peuvent l’accompagner. Vous rencontrerez aussi des carrosseries moulées en résine, par exemple chez OttOmobile au 1:18. Pour savoir si les roues tournent ou si les portes s’ouvrent, fiez-vous à la fiche de la référence. Examinez la peinture autour des creux et des jonctions. Si la livrée est tampographiée, regardez la netteté des marquages et l’alignement des couleurs. Sur un profil, vérifiez le centrage des roues dans les passages d’aile. Sur un plan plat, regardez si les quatre pneus touchent le sol. De face, observez si les optiques et les rétroviseurs sont alignés. Des phares transparents montés séparément peuvent donner davantage de relief que des phares peints. Regardez surtout la netteté de leur contour. Les vues en trois quarts sont les plus flatteuses. Demandez aussi un profil et une vue arrière si la fiche s’en tient à un seul angle.</p>
      ${figure('angles/01.webp','Skyline ER34 blanche de face, des deux profils et de dos','Quatre vues illustratives · Vérifiez l’aileron, les roues et les marquages d’un angle à l’autre.')}` },
      { id: 'achat', title: 'Vérifiez la fiche avant de choisir', body: `
      <p>Le poids est une sensation en main. Pour juger le modèle, comparez surtout la régularité de l’assemblage et la fidélité à la version représentée. Selon la référence, vérifiez la présence d’un socle, d’une boîte ou de pièces mobiles. Si vous achetez pour un décor existant, regardez la place disponible et la hauteur de l’aileron. La valeur de revente dépend du modèle, de son état et du marché. Pour une première pièce, fixez un budget que vous seriez satisfait d’avoir consacré à l’exposer.</p>
      ${checklist('Avant de vous décider', ['Confirmez la génération, la livrée et la référence.', 'Regardez au moins une vue de profil et une vue arrière.', 'Vérifiez le contenu, le socle et les dimensions utiles.'])}
      <p>Vous hésitez sur l’encombrement ? Consultez le <a href="/journal/echelle-1-64-taille-voiture-miniature/">guide des tailles au 1:64</a>.</p>` },
    ],
  },
  {
    slug: 'creer-diorama-garage-1-64',
    category: 'Diorama',
    title: 'Créer un diorama de garage au 1:64',
    shortTitle: 'Monter un diorama de garage',
    description: 'Aménagez un diorama de garage au 1:64 avec une voiture, des accessoires à l’échelle et un éclairage qui met le décor en valeur.',
    lead: 'Une voiture, une place de stationnement et un peu de lumière suffisent à faire vivre un garage miniature.',
    image: 'assets/pack-er34-scene.jpg',
    alt: 'Mise en scène illustrative avec la Skyline ER34 blanche dans le garage Atelier de nuit',
    caption: 'Exemple de composition · Atelier de nuit et Nissan Skyline ER34.',
    product: 'garage',
    sections: [
      { id: 'espace', title: 'Préparez la surface utile du garage', body: `
      <p>Vérifiez la largeur entre les murs et la place que prennent le pont, les servantes et les poteaux. Ce sont ces éléments qui décident où une voiture peut se garer. Posez le décor vide sur une surface plane, vérifiez le dégagement à l’arrière pour le câble USB, puis faites un premier essai sans fixer les accessoires. Placez la voiture face à l’ouverture, puis faites un essai de trois quarts à environ 30 degrés pour montrer la calandre et les jantes dans le même cadre. Choisissez la position qui laisse visibles à la fois la carrosserie et ce qui donne son caractère à l’atelier.</p>` },
      { id: 'accessoires', title: 'Donnez une fonction à chaque accessoire', body: `
      <p>Dans un vrai atelier, le matériel se trouve près de l’endroit où on l’utilise. Reprenez cette logique à petite échelle. Posez un chariot près du pont, quelques pneus contre un mur et un ou deux cônes en limite de la zone de travail. Un rack de roues en hauteur peut habiller le mur tout en laissant le sol dégagé. Pour contrôler la taille d’un élément, divisez sa cote réelle par 64. Un cône de 50 cm, par exemple, ferait environ 8 mm. Une rangée d’accessoires de taille cohérente donnera plus de profondeur que des objets disposés partout au premier plan.</p>
      ${figure('21.jpg','Garage Atelier de nuit vide, avec ponts jaunes et rampe LED','Décor seul · Le plan de travail reste dégagé entre les ponts et l’ouverture.')}` },
      { id: 'lumiere', title: 'Cherchez le contraste avant d’ajouter de la lumière', body: `
      <p>Dans l’Atelier de nuit, les ponts jaunes dessinent des lignes verticales derrière la Skyline ER34 blanche. Si le fond clair efface les contours de la voiture, avancez-la et tournez-la de quelques degrés. Observez le pare-brise depuis le bord de la table. Si la rampe s’y reflète en plein milieu, changez d’abord l’angle de la voiture. Une feuille blanche posée à côté de l’ouverture peut ensuite éclaircir le côté sombre sans multiplier les sources de lumière.</p>
      <figure class="journal-figure"><video controls playsinline preload="none" poster="/assets/pack-er34-scene.jpg" width="1080" height="720" aria-label="Montage visuel du garage et de la miniature">
        <source src="/assets/journal-atelier.mp4" type="video/mp4"><track kind="captions" src="/assets/journal-atelier.vtt" srclang="fr" label="Descriptions en français">Votre navigateur peut <a href="/assets/journal-atelier.mp4">ouvrir le montage vidéo</a>.
      </video><figcaption>Montage illustratif de 15 s, sans son. Le garage vide, la Skyline seule, puis la scène composée.</figcaption></figure>
      ${checklist('Les trois derniers réglages', ['Laissez du recul pour le câble USB.', 'Libérez le premier plan pour lire la silhouette.', 'Allumez le décor et observez les reflets à hauteur de la voiture.'])}
      <p>Le décor est prêt ? Passez aux <a href="/journal/photographier-voiture-miniature-smartphone/">photos de miniatures au smartphone</a>.</p>` },
    ],
  },
  {
    slug: 'photographier-voiture-miniature-smartphone',
    category: 'Photo',
    title: 'Photographier ses miniatures au smartphone',
    shortTitle: 'Photographier ses miniatures',
    description: 'Un guide simple pour photographier une voiture miniature au smartphone avec un éclairage doux, un angle bas et des reflets maîtrisés.',
    lead: 'Pour donner du volume à une miniature, baissez le téléphone et déplacez la lumière. Vous pouvez commencer avec une fenêtre et une feuille blanche.',
    image: 'assets/05.jpg',
    alt: 'Mazda RX-7 bleue en miniature vue de trois quarts dans un décor sombre',
    caption: 'RX-7 au 1:64 · Exemple de cadrage rapproché de trois quarts.',
    product: '13',
    sources: [['Apple · Régler la mise au point et l’exposition sur iPhone', 'https://support.apple.com/fr-fr/guide/iphone/-iph3dc593597/ios']],
    sections: [
      { id: 'lumiere', title: 'Installez une lumière douce sur le côté', body: `
      <p>Placez la miniature près d’une fenêtre sans soleil direct. Un voilage clair adoucit la lumière. Disposez une feuille blanche de l’autre côté de la voiture pour déboucher l’ombre. Coupez le flash du téléphone et regardez le capot à l’écran. Si une tache blanche masque les détails de la peinture, tournez légèrement la voiture. Vous pouvez aussi éloigner la feuille jusqu’à obtenir un reflet qui souligne l’aile sans l’effacer.</p>` },
      { id: 'angle', title: 'Descendez à hauteur des phares', body: `
      <p>Posez la voiture sur une table avec un fond qui se prolonge derrière elle. Cadrez d’abord de trois quarts avant, téléphone à hauteur des phares, en gardant assez de recul pour avoir une image nette. Si l’objectif est placé en haut du téléphone, retournez celui-ci pour le rapprocher du sol et calez-le sur un support. Touchez le phare ou la jonction de l’aile et du capot à l’écran pour faire la mise au point. Si le téléphone permet de verrouiller mise au point et exposition, activez ce réglage pour comparer plusieurs cadrages à lumière constante. Quand l’appareil peine à faire le point, reculez un peu et recadrez ensuite.</p>
      <div class="journal-comparison">
        ${figure('angles/01.webp','Planche de la Skyline ER34 montrant la face, les deux profils et l’arrière','Vues de face et de profil · Utiles pour lire les proportions.')}
        ${figure('01.jpg','Skyline ER34 blanche en vue de trois quarts avant','Trois quarts bas · Le capot et les ailes prennent du volume.')}
      </div>` },
      { id: 'serie', title: 'Prenez deux vues avec la même lumière', body: `
      <p>Commencez par un profil, téléphone parallèle à la voiture. Vous pourrez lire la silhouette, la position des roues et les décors latéraux. Pour la seconde image, déplacez le téléphone vers l’avant et gardez la même hauteur. En regardant les deux photos côte à côte, choisissez le profil pour décrire le modèle et le trois quarts pour une scène qui évoque une vraie voiture. Reprenez une image si le reflet recouvre le détail qui doit attirer l’œil.</p>
      ${checklist('Avant de déclencher', ['Nettoyez l’objectif et retirez les poussières de la miniature.', 'Vérifiez que les roues et les rétroviseurs entrent dans le cadre.', 'Appuyez le téléphone sur un support si la lumière manque.'])}
      <p>Pour donner un contexte à votre prochaine série, <a href="/journal/creer-diorama-garage-1-64/">aménagez votre décor de garage</a>.</p>` },
    ],
  },
];
