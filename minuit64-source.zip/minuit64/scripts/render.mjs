import { cp, mkdir, readFile, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const source = join(root, 'dist');
const target = process.argv[2] && resolve(process.argv[2]);
const origin = process.argv[3];

if (!target || target === source || target.startsWith(source + '/')) {
  throw new Error('Indiquez un dossier d’export hors de dist.');
}
if (!/^https:\/\/[a-z0-9-]+\.onrender\.com$/.test(origin || '')) {
  throw new Error('Indiquez l’origine HTTPS attribuée par Render.');
}

await mkdir(target, { recursive: true });
await cp(source, target, { recursive: true });
const build = spawnSync(process.execPath, [join(root, 'scripts/build.mjs')], {
  env: { ...process.env, MINUIT_DIST: target, MINUIT_ORIGIN: origin },
  stdio: 'inherit',
});
if (build.error) throw build.error;
if (build.status !== 0) throw new Error('La génération Render a échoué.');

const homePath = join(target, 'index.html');
const home = await readFile(homePath, 'utf8');
await writeFile(homePath, home.replace('</head>', '  <meta name="minuit-checkout" content="test">\n</head>'));
console.log('Render · ' + origin + ' · ' + target);
