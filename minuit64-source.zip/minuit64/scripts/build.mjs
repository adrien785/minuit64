import { mkdir, readFile, writeFile, readdir, rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import vm from 'node:vm';
import { journal } from './journal.mjs';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const dist = resolve(root, process.env.MINUIT_DIST || 'dist');
const origin = new URL(process.env.MINUIT_ORIGIN || 'https://minuit64.pages.dev').origin;
const catalogue = await readFile(join(dist, 'catalogue.js'), 'utf8');
const {cars, garages, productPath} = vm.runInNewContext(catalogue + '\n;({cars, garages, productPath})');
const write = (path, data) => writeFile(join(dist, path), data);
const escape = value => String(value).replace(/[&<>"']/g, ch => ({
  '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;',
})[ch]);
const structured = value => '<script type="application/ld+json">' + JSON.stringify(value).replace(/</g, '\\u003c') + '</script>';
const money = cents => new Intl.NumberFormat('fr-FR', {style:'currency', currency:'EUR'}).format(cents/100);
const homeTitle = 'Minuit 64 | Voitures miniatures 1:64 et garages LED';
const homeDescription = 'Explorez 20 voitures japonaises en miniature au 1:64 et 8 garages LED. Composez votre pack voiture et diorama dans l’univers du tuning japonais.';
const families = [
  {path:'/miniatures/', label:'Miniatures', title:'Voitures miniatures au 1:64', items:cars, image:'assets/01.jpg',
   description:'Découvrez 20 miniatures japonaises au 1:64, des Skyline aux RX-7. Explorez les livrées, les préparations et les modèles de course.'},
  {path:'/garages/', label:'Garages LED', title:'Garages LED au 1:64', items:garages, image:'assets/21.jpg',
   description:'Découvrez 8 dioramas de garage au 1:64 en bois et acrylique, avec accessoires d’atelier et éclairage LED USB.'},
];

function head(title, description, path, image, type = 'website') {
  const url = origin + path;
  return `<title>${escape(title)}</title>
  <meta name="description" content="${escape(description)}">
  <link rel="canonical" href="${url}">
  <meta property="og:site_name" content="Minuit 64">
  <meta property="og:locale" content="fr_FR">
  <meta property="og:type" content="${type}">
  <meta property="og:title" content="${escape(title)}">
  <meta property="og:description" content="${escape(description)}">
  <meta property="og:url" content="${url}">
  <meta property="og:image" content="${origin}/${image}">
  <meta name="twitter:card" content="summary_large_image">`;
}

function crumbs(family, label, path) {
  const links = [['Accueil','/'],[family.label,family.path]];
  if (label) links.push([label, path]);
  return structured({'@context':'https://schema.org','@type':'BreadcrumbList',itemListElement:links.map(([name,path],i) =>
    ({'@type':'ListItem',position:i+1,name,item:origin+path}))});
}

function itemList(family) {
  return structured({'@context':'https://schema.org','@type':'ItemList',name:family.title,itemListElement:family.items.map((item,i) =>
    ({'@type':'ListItem',position:i+1,url:origin+productPath(item),name:item.name+' · '+item.variant}))});
}

function layout(meta, body, { journal = false, calculator = false } = {}) {
  return `<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#141511">
  ${meta}
  <link rel="icon" href="/assets/mark.svg" type="image/svg+xml">
  <link rel="preload" href="/assets/barlow-900-italic.woff2" as="font" type="font/woff2" crossorigin>
  <link rel="stylesheet" href="/style.css?v=10">${journal ? '\n  <link rel="stylesheet" href="/journal.css?v=1">' : ''}${calculator ? '\n  <script defer src="/journal.js?v=1"></script>' : ''}
</head>
<body>
  <a class="skip" href="#contenu">Aller au contenu</a>
  <div class="announcement"><span></span> AVANT-PREMIÈRE <i></i> PRIX INDICATIFS</div>
  <header class="header"><div class="header-inner wrap">
    <a class="brand" href="/" aria-label="Minuit 64, accueil"><img src="/assets/mark.svg" width="36" height="28" alt=""><span>MINUIT<span class="brand-accent">64</span><small>DIECAST CLUB</small></span></a>
    <nav aria-label="Navigation principale"><a href="/miniatures/">Miniatures</a><a href="/#packs">Les packs</a><a href="/garages/">Garages</a><a href="/journal/"${journal ? ' aria-current="page"' : ''}>Journal</a></nav>
    <a class="catalogue-back" href="/">Boutique ↗</a>
  </div></header>
  <main id="contenu" class="wrap seo-page">${body}</main>
  <footer class="footer"><div class="wrap footer-inner"><a href="/">MINUIT 64</a><p>Voitures miniatures et garages LED au 1:64.</p><a class="footer-journal" href="/journal/">Le Journal</a><span class="footer-note">COLLECTION 01 · AVANT-PREMIÈRE</span></div></footer>
</body>
</html>\n`;
}

function linkGrid(family) {
  return `<div class="seo-grid">${family.items.map(item => `<article class="product-card">
    <a class="card-media" href="${productPath(item)}"><img src="/${item.image.replace('.jpg','-card.jpg')}" alt="${escape(item.name+' '+item.variant)}" loading="lazy" decoding="async"></a>
    <div class="card-body"><div class="card-meta"><span>${escape(item.type==='car' ? item.make : 'DIORAMA LED')}</span><span>1:64</span></div>
    <h2><a href="${productPath(item)}">${escape(item.name)}</a></h2><p>${escape(item.variant)}</p></div>
    </article>`).join('')}</div>`;
}

function productPage(family, item) {
  const isCar = item.type === 'car';
  const kind = isCar ? 'Miniature 1:64' : 'Garage LED 1:64';
  const title = item.name + ' · ' + item.variant + ' | Minuit 64';
  const specLine = isCar ? 'Carrosserie en alliage moulé.' : 'Bois et acrylique, éclairage LED USB.';
  const fields = isCar ? [['Échelle','1:64'],['Carrosserie','Alliage moulé'],['Fabricant',item.brand],['Finition',item.variant]]
    : [['Échelle','1:64'],['Dimensions','30 × 20 × 9,6 cm'],['Structure','Bois et acrylique'],['Éclairage','LED USB']];
  const image = isCar ? 'assets/angles/'+item.visual+'.webp' : item.image;
  const alt = isCar ? item.name+' · vue de face, deux profils et arrière' : 'Garage LED '+item.name+' au 1:64';
  const related = isCar ? garages[0] : cars.find(car=>car.id===item.suggestedCar);
  return layout(head(title,kind+'. '+item.description+' '+specLine,productPath(item),item.image) + '\n  ' + crumbs(family, item.name, productPath(item)),
    `<nav class="breadcrumbs" aria-label="Fil d’Ariane"><a href="/">Accueil</a><span aria-hidden="true">/</span><a href="${family.path}">${family.label}</a><span aria-hidden="true">/</span><span aria-current="page">${escape(item.name)}</span></nav>
    <article class="seo-product">
      <figure class="seo-product-image${isCar?' seo-angles':''}"><img src="/${image}" alt="${escape(alt)}" width="1200" height="800" fetchpriority="high"><figcaption>${isCar?'Vues illustratives · Face, profils et arrière':'Vue illustrative du décor'}</figcaption></figure>
      <div class="seo-product-info">
        <p class="eyebrow section-kicker">// ${kind}</p><h1>${escape(item.name)}<span>.</span></h1>
        <p class="variant">${escape(item.variant)}</p><p class="seo-description">${escape(item.description)}</p>
        <dl>${fields.map(([name,value])=>`<div><dt>${name}</dt><dd>${escape(value)}</dd></div>`).join('')}</dl>
        <p>${isCar?'Contenu · Une miniature vendue à l’unité.':'Contenu · Garage à assembler, accessoires et éclairage LED USB.'}</p>
        <p class="seo-price">${money(item.price)} <small>Prix indicatif</small></p>
        <div class="seo-actions"><a class="button acid" href="/?produit=${item.id}#${isCar?'collection':'atelier'}">Voir dans la boutique ↗</a><a class="button line" href="/?${isCar?'voiture':'garage'}=${item.id}#packs">Composer un pack</a></div>
        <p class="seo-related">À associer avec <a href="${productPath(related)}">${escape(related.name)}</a>.</p>
      </div>
    </article>`);
}

for (const family of families) {
  const directory = family.path.slice(1,-1);
  await mkdir(join(dist,directory),{recursive:true});
  const children = new Set(family.items.map(item=>productPath(item).split('/')[2]));
  for (const dir of await readdir(join(dist,directory),{withFileTypes:true})) {
    if (dir.isDirectory() && !children.has(dir.name)) await rm(join(dist,directory,dir.name),{recursive:true});
  }
  await write(directory+'/index.html',layout(head(family.title+' | Minuit 64',family.description,family.path,family.image)+'\n  '+crumbs(family)+'\n  '+itemList(family),
    `<nav class="breadcrumbs" aria-label="Fil d’Ariane"><a href="/">Accueil</a><span aria-hidden="true">/</span><span aria-current="page">${family.label}</span></nav>
    <div class="seo-heading"><p class="eyebrow section-kicker">// COLLECTION 01</p><h1>${family.title}<span>.</span></h1><p>${family.description}</p></div>${linkGrid(family)}`));
  for (const item of family.items) {
    const folder = productPath(item).slice(1,-1);
    await mkdir(join(dist,folder),{recursive:true});
    await write(folder+'/index.html',productPage(family,item));
  }
}

const replaceBlock = (source, key, content) => {
  const marker = new RegExp(`<!-- ${key}:START -->[\\s\\S]*?<!-- ${key}:END -->`);
  if (!marker.test(source)) throw new Error('Repère manquant : '+key);
  return source.replace(marker,()=>`<!-- ${key}:START -->\n  ${content}\n  <!-- ${key}:END -->`);
};
let home = await readFile(join(dist,'index.html'),'utf8');
home = replaceBlock(home,'SEO',head(homeTitle,homeDescription,'/','assets/hero.jpg')+'\n  '+structured({
  '@context':'https://schema.org','@type':'WebSite',name:'Minuit 64',url:origin+'/',inLanguage:'fr',
}));
const editorial = journal({ layout, head, crumbs, structured, escape, origin, productPath, cars, garages });
for (const [path, html] of editorial.pages) {
  const folder = path.slice(1,-1);
  await mkdir(join(dist,folder),{recursive:true});
  await write(folder+'/index.html',html);
}
home = replaceBlock(home,'JOURNAL',editorial.home);
await write('index.html',home);
const urls = ['/',...families.flatMap(f=>[f.path,...f.items.map(productPath)]),...editorial.paths];
if (new Set(urls).size !== urls.length) throw new Error('Adresses de fiches en double');
await write('sitemap.xml','<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
  urls.map(url=>'  <url><loc>'+origin+url+'</loc></url>').join('\n')+'\n</urlset>\n');
await write('robots.txt','User-agent: *\nAllow: /\nDisallow: /api/\nSitemap: '+origin+'/sitemap.xml\n');
console.log(`${urls.length} pages, ${cars.length} miniatures, ${garages.length} garages · ${origin}`);
