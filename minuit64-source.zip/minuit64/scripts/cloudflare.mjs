import { cp, mkdir, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const source = join(root,'dist');
const target = process.argv[2] && resolve(process.argv[2]);
if (!target || target === source || target.startsWith(source+'/')) throw new Error('Indiquez un dossier d’export hors de dist.');
await mkdir(target,{recursive:true});
await cp(source,target,{recursive:true});
const home = await readFile(join(target,'index.html'),'utf8');
await writeFile(join(target,'index.html'),home.replace('</head>','  <meta name="minuit-checkout" content="test">\n</head>'));
const catalogue = await readFile(join(source,'catalogue.js'),'utf8');
const checkout = await readFile(join(root,'worker/checkout.mjs'),'utf8');
await writeFile(join(target,'_worker.js'),catalogue+'\n'+checkout);
await writeFile(join(target,'_routes.json'), JSON.stringify({version:1,include:['/api/*'],exclude:[]})+'\n');
console.log('Cloudflare Pages · '+target);
