const noCache = {'Cache-Control':'no-store', 'X-Robots-Tag':'noindex'};
const json = (value, status=200) => Response.json(value, {status, headers:noCache});
const token = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const sandboxKey = env => /^(?:sk|rk)_test_[a-zA-Z0-9]+$/.test(env.STRIPE_TEST_SECRET_KEY ?? '');
const stripeHost = 'https://api.stripe.com/v1/checkout/sessions';
const api = {
  config:'/api/checkout/config',
  start:'/api/checkout/session',
  result:'/api/checkout/result',
};

async function readSmallJson(request) {
  if (!request.headers.get('content-type')?.toLowerCase().startsWith('application/json') || !request.body) return null;
  const reader = request.body.getReader();
  const decoder = new TextDecoder();
  let size = 0;
  let text = '';
  try {
    for (;;) {
      const {value,done} = await reader.read();
      if (done) return JSON.parse(text+decoder.decode());
      size += value.byteLength;
      if (size > 8192) {
        await reader.cancel();
        return null;
      }
      text += decoder.decode(value,{stream:true});
    }
  } catch {
    return null;
  } finally {
    reader.releaseLock();
  }
}

function validatedCart(lines) {
  if (!Array.isArray(lines) || lines.length < 1 || lines.length > 25) return null;
  const selected = new Map();
  let count = 0;
  for (const line of lines) {
    if (!line || typeof line.id !== 'string' || !Number.isInteger(line.quantity) || line.quantity < 1 || line.quantity > 20) return null;
    const item = items.get(line.id);
    if (!item || selected.has(item.id)) return null;
    count += line.quantity;
    if (count > 50) return null;
    selected.set(item.id, {item, quantity:line.quantity});
  }
  return [...selected.values()].sort((a,b) => a.item.id.localeCompare(b.item.id));
}

async function stripe(path, env, options={}) {
  const headers = new Headers(options.headers);
  headers.set('Authorization','Bearer '+env.STRIPE_TEST_SECRET_KEY);
  const response = await fetch(stripeHost+path,{...options,headers});
  if (!response.ok) throw new Error('Stripe indisponible ('+response.status+')');
  return response.json();
}

async function createSession(payload, origin, env) {
  const cart = validatedCart(payload?.items);
  if (!cart || !token.test(payload.requestId ?? '')) return json({message:'Vérifiez le panier et réessayez.'},400);
  const form = new URLSearchParams({
    mode:'payment', locale:'fr',
    success_url:origin+'/?paiement=test&session_id={CHECKOUT_SESSION_ID}',
    cancel_url:origin+'/?paiement=annule',
    'metadata[minuit64]':'sandbox',
    'payment_intent_data[description]':'Minuit 64 · Commande de test',
  });
  cart.forEach(({item,quantity}, i) => {
    const path = 'line_items['+i+']';
    form.set(path+'[quantity]',String(quantity));
    form.set(path+'[price_data][currency]','eur');
    form.set(path+'[price_data][unit_amount]',String(item.price));
    form.set(path+'[price_data][product_data][name]',item.name+' · '+item.variant);
    form.set(path+'[price_data][product_data][metadata][reference]',item.id);
  });
  const session = await stripe('',env,{
    method:'POST',body:form,headers:{
      'Content-Type':'application/x-www-form-urlencoded',
      'Idempotency-Key':'minuit64-test-'+payload.requestId,
    },
  });
  const redirect = new URL(session.url);
  if (session.livemode !== false || !/^cs_test_/.test(session.id) || redirect.origin !== 'https://checkout.stripe.com') {
    throw new Error('Session de test non valide');
  }
  return json({url:redirect.href});
}

async function result(payload, env) {
  if (typeof payload?.id !== 'string' || !/^cs_test_[A-Za-z0-9_]{12,300}$/.test(payload.id)) {
    return json({message:'Référence de test non valide.'},400);
  }
  const session = await stripe('/'+encodeURIComponent(payload.id),env);
  if (session.livemode !== false || session.metadata?.minuit64 !== 'sandbox') return json({message:'Session non trouvée.'},404);
  return json({paid:session.status==='complete' && session.payment_status==='paid'});
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const {pathname} = url;
    if (!pathname.startsWith('/api/')) return env.ASSETS.fetch(request);
    if (pathname===api.config && request.method==='GET') return json({enabled:sandboxKey(env),mode:'test'});
    if (![api.start,api.result].includes(pathname)) return json({message:'Page introuvable.'},404);
    if (request.method!=='POST') return json({message:'Méthode non autorisée.'},405);
    const shopOrigin = request.headers.get('Origin');
    if (shopOrigin!==url.origin && (!env.PUBLIC_SHOP_ORIGIN || shopOrigin!==env.PUBLIC_SHOP_ORIGIN)) {
      return json({message:'Demande non autorisée.'},403);
    }
    if (!sandboxKey(env)) return json({message:'Le paiement de test attend la connexion à Stripe.'},503);
    const payload = await readSmallJson(request);
    try {
      return pathname===api.start ? await createSession(payload,shopOrigin,env) : await result(payload,env);
    } catch {
      return json({message:'Stripe Test est momentanément indisponible. Réessayez dans un instant.'},502);
    }
  },
};
